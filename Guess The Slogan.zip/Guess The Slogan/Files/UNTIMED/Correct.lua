display.setStatusBar(display.HiddenStatusBar)
centerX = display.contentWidth / 2
centerY = display.contentHeight / 2

local widget = require("widget")
local composer = require ("composer")
local scene = composer.newScene()
composer.recycleOnSceneChange = true

local BlackBG, correct, coin1, coin2, coin3, coin4, Next, plus

local function onUpdate( event )
    
end

function scene:create( event )
    local sceneGroup = self.view

 	BlackBG = display.newImageRect("Images/BlackBG.png", 2500, 500)
    BlackBG.x = centerX
    BlackBG.y = centerY
    sceneGroup:insert( BlackBG )

    coin1 = display.newImageRect("Images/earnCoin.png", 40, 40)
    coin1.x = 173
    coin1.y = -20
    sceneGroup:insert( coin1 )
    transition.to(coin1, {time = 1100, x = 173, y = 200, transition = easing.outBounce})

    coin2 = display.newImageRect("Images/earnCoin.png", 40, 40)
    coin2.x = 218
    coin2.y = -20
    sceneGroup:insert( coin2 )
    transition.to(coin2, {time = 1400, x = 218, y = 200, transition = easing.outBounce})

    coin3 = display.newImageRect("Images/earnCoin.png", 40, 40)
    coin3.x = 263
    coin3.y = -20
    sceneGroup:insert( coin3 )
    transition.to(coin3, {time = 1700, x = 263, y = 200, transition = easing.outBounce})

    coin4 = display.newImageRect("Images/earnCoin.png", 40, 40)
    coin4.x = 308
    coin4.y = -20
    sceneGroup:insert( coin4 )
    transition.to(coin4, {time = 2000, x = 308, y = 200, transition = easing.outBounce})

    correct = display.newImageRect("Images/correct.png", 330, 120)
    correct.x = 235
    correct.y = 75
    sceneGroup:insert( correct )

    plus = display.newText("+4", centerX, 150, "Cooper Black", 30)
    plus:setTextColor(1)
    sceneGroup:insert( plus )

Next = widget.newButton
{
    width = 150,
    height = 45,
    defaultFile = "Images/next.png",
    overFile = "Images/next1.png",
}
Next.x = centerX
Next.y = 260
sceneGroup:insert( Next )
Next:addEventListener( "tap", Next )
function Next:tap( event )
    composer.hideOverlay( "slideRight", 500 )
end
	
end

------------- Enter Scene ------------------------------------------------------------------------------------------

function scene:show( event )
    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Called when the scene is still off screen (but is about to come on screen).
    elseif ( phase == "did" ) then
        -- Called when the scene is now on screen.
        -- Insert code here to make the scene come alive.
        -- Example: start timers, begin animation, play audio, etc.
    end
end

function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase

    if ( event.phase == "will" ) then
        -- Called when the scene is on screen (but is about to go off screen).
        -- Insert code here to "pause" the scene.
        -- Example: stop timers, stop animation, stop audio, etc.
    elseif ( phase == "did" ) then
        -- Called immediately after scene goes off screen.
    end
end

function scene:destroy( event )
    local sceneGroup = self.view

    -- Called prior to the removal of scene's view ("sceneGroup").
    -- Insert code here to clean up the scene.
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene