display.setStatusBar(display.HiddenStatusBar)
centerX = display.contentWidth / 2
centerY = display.contentHeight / 2

local widget = require("widget")
local composer = require ("composer")
local scene = composer.newScene()
composer.recycleOnSceneChange = true

local BlackBG, Resume, Quit, Pause, label

local function onUpdate( event )
    
end

function scene:create( event )
    local sceneGroup = self.view

 	BlackBG = display.newImageRect("Images/BlackBG.png", 2500, 500)
    BlackBG.x = centerX
    BlackBG.y = centerY
    sceneGroup:insert( BlackBG )

    Pause = display.newImageRect("Images/Popup.png", 250, 230)
    Pause.x = centerX
    Pause.y = centerY
    sceneGroup:insert( Pause )

    label = display.newText("Pause", centerX, 75, "GrilledCheese BTN Toasted", 30)
    label:setFillColor(0)
    sceneGroup:insert( label )

Resume = widget.newButton
{
    width = 150,
    height = 45,
    defaultFile = "Images/Resumebutton.png",
    overFile = "Images/Resumebutton1.png",
}
Resume.x = centerX
Resume.y = 178
sceneGroup:insert( Resume )
Resume:addEventListener( "tap", Resume )
function Resume:tap( event )
    composer.hideOverlay( "slideRight", 500 )
end

Quit = widget.newButton
{
    width = 150,
    height = 45,
    defaultFile = "Images/Quitbutton.png",
    overFile = "Images/Quitbutton1.png",
}
Quit.x = centerX
Quit.y = 230
sceneGroup:insert( Quit )
Quit:addEventListener( "tap", Quit )
function Quit:tap( event )
    local Quit = {
    effect = "corssFade",
    time = 500,
    isModal = true
    }
    composer.gotoScene( "Files.mainscreen", Quit )
end
	
end

------------- Enter Scene ------------------------------------------------------------------------------------------

function scene:show( event )
    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Called when the scene is still off screen (but is about to come on screen).
    elseif ( phase == "did" ) then
        -- Called when the scene is now on screen.
        -- Insert code here to make the scene come alive.
        -- Example: start timers, begin animation, play audio, etc.
    end
end

function scene:hide( event )
    local sceneGroup = self.view
    local phase = event.phase

    if ( event.phase == "will" ) then
        -- Called when the scene is on screen (but is about to go off screen).
        -- Insert code here to "pause" the scene.
        -- Example: stop timers, stop animation, stop audio, etc.
    elseif ( phase == "did" ) then
        -- Called immediately after scene goes off screen.
    end
end

function scene:destroy( event )
    local sceneGroup = self.view

    -- Called prior to the removal of scene's view ("sceneGroup").
    -- Insert code here to clean up the scene.
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene